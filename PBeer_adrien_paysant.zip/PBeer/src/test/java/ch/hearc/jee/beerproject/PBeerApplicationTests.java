package ch.hearc.jee.beerproject;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class PBeerApplicationTests {

	@Test
	void contextLoads() {
	}

}
