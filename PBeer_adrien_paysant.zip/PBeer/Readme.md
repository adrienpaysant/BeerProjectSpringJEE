Little beer management project made with SpringBoot & Thymeleaf.




main image source : 

https://portugalinews.eu/nortada-and-dott-deliver-craft-beer-at-home/


By Adrien Paysant => https://github.com/adrienpaysant